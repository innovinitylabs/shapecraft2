import * as THREE from 'https://threejs.org/build/three.module.js';
import { OrbitControls } from 'https://threejs.org/examples/jsm/controls/OrbitControls.js';

var CONTAINER, RENDERER, SCENE, CAMERA, CONTROLS;

init();
animate();

function init() {
    RENDERER = new THREE.WebGLRenderer({
        antialias: true, alpha:true
    });
    RENDERER.setSize(window.innerWidth, window.innerHeight);
    CONTAINER = document.createElement('div');
    document.body.appendChild(CONTAINER);
    CONTAINER.appendChild(RENDERER.domElement);

    SCENE = new THREE.Scene();

    CAMERA = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 5000);
    CAMERA.position.set(0, 0,100);
    CAMERA.lookAt(SCENE.position);
    
    CONTROLS = new OrbitControls(CAMERA, RENDERER.domElement);
    CONTROLS.mouseButtons = {LEFT: THREE.MOUSE.ROTATE}
    CONTROLS.maxPolarAngle = Math.PI-Math.PI/6.0;
    CONTROLS.minPolarAngle =Math.PI/6.0;
    CONTROLS.enableDamping = true;

    var shaderSphereGeometry = new THREE.SphereGeometry(15, 64, 64);
    var shaderMaterial = new THREE.ShaderMaterial({
        vertexShader:   document.getElementById('sphere-vertex-shader').textContent,
        fragmentShader: document.getElementById('sphere-fragment-shader').textContent
    });
    var shaderSphere = new THREE.Mesh(shaderSphereGeometry, shaderMaterial);
    shaderSphere.rotation.x = 0.25;
    shaderSphere.rotation.y = 0.25;
    SCENE.add(shaderSphere);
    
    window.addEventListener('resize', onWindowResize, false); 
}

function animate() {
    requestAnimationFrame(animate);
    CONTROLS.update();
    RENDERER.render(SCENE, CAMERA);
}

function onWindowResize(event) {
    CAMERA.aspect = window.innerWidth / window.innerHeight;
    CAMERA.updateProjectionMatrix();
    RENDERER.setSize(window.innerWidth, window.innerHeight);
}