# 3D flower shader

A Pen created on CodePen.

Original URL: [https://codepen.io/fjiumqtd-the-decoder/pen/oNOyKKO](https://codepen.io/fjiumqtd-the-decoder/pen/oNOyKKO).

three.js (rotation with mouse)